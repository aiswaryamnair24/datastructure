#include<stdio.h>
#include<stdlib.h>
void insertatbegin();
void insertatlast();
void insertatloc();
void deletebegin();
void deletelast();
void deleteatloc();
void display();
void exit();
struct node
{
int data;
struct node *next;
struct node *prev;
}*head=NULL;
void main()
{
int choice;
do
{
printf("1.Insertion at beginning\n2.insertion at last\n3.Insertion at specific position\n4.Deletion from beginning\n5. delete from last\n6.Deletion from specific position\n 7.display\n8.exit(0)");
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:insertatbegin();
        break;
case 2:insertatlast();
        break;
case 3:insertatloc();
        break;
case 4:deletebegin();
        break;
case 5:deletelast();
        break;
case 6:deleteatloc();
        break;
case 7:display();
        break;
case 8:exit(0);
        break;
default:printf("invalid choice");
}
}while(choice!=9);
}
void insertatbegin()
{
    struct node *newnode=(struct node*)malloc(sizeof(struct node));
    int value;
    printf("enter the value to insert");
    scanf("%d",&value);
    newnode->data=value;
    if(head==NULL)
    {
        newnode->prev=NULL;
        newnode->next=NULL;
        head=newnode;
    }
    else
    {
        newnode->data=value;
        newnode->next=head;
        newnode->prev=NULL;
        head=newnode;
    }
    printf("element inserted at beginning\n");
}
void insertatlast()
{
   struct node *newnode=(struct node*)malloc(sizeof(struct node));
    int value;
    printf("enter the value to insert");
    scanf("%d",&value);
    newnode->data=value;
    if(head==NULL)
    {
        newnode->prev=NULL;
        newnode->next=NULL;
        head=newnode;
    }
    else
    {
        struct node *temp = head;
      while(temp->next != NULL)
      {
        temp = temp->next;
      }
        temp->next = newnode;
        newnode->prev=temp;
        newnode->next=NULL;
    }
}
void insertatloc()
{struct node*temp;
temp=head;
int item,pos;
struct node*newnode=(struct node*)malloc(sizeof(struct node));
printf("enter the element:");
scanf("%d",&item);
printf("enter the location:");
scanf("%d",&pos);
newnode->data=item;
if(head==NULL)
{
    head=newnode;
    newnode->next=NULL;
    newnode->prev=NULL;
}
else
    {
        while(temp->next!=NULL&&temp->data!=pos)
        {
            temp=temp->next;

            if(temp->next==NULL)
            {
                printf("\nelement not found:");
            }
        }
        newnode->next=temp->next;
        temp->next=newnode;
        newnode->prev=temp;
        newnode->next->prev=newnode;
    }
}

void deletebegin()
{
    if(head==NULL)
    {
        printf("list is empty no node to delete");
    }
    else
    {
        struct node *temp=head;
        head=head->next;
        free(temp);
    }
}
 void deletelast()
{
   struct node*temp;
temp=head;
    if(head==NULL)
    {
        printf("deletion not possible:");
    }
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->prev->next=NULL;
    temp->prev=NULL;
    free(temp);
}
    void deleteatloc()
    {
        if(head==NULL)
        {

            printf("list is empty no node to delete");
        }
        else
            {
                int key;
            struct node *temp=head;
            printf("enter the key value");
            scanf("%d",&key);
            while(temp->data!=key)
            {
                if(temp->next==NULL)
                {
                    printf("element not found");
                }
                else
                    temp=temp->next;
                if(temp->prev==NULL && temp->next==NULL)
                {

                    head=NULL;
                    free(temp);
                }
                else if(temp->prev==NULL &&temp->next!=NULL)

                {
                    head=temp->next;
                    head->prev=NULL;
                    free(temp);
                }
                else if(temp->prev!=NULL && temp->next==NULL)
                {

                    temp->prev->next==NULL;
                    free(temp);
                }
                else{
                    temp->next->prev==temp->prev;
                    temp->prev->next==temp->next;
                    free(temp);

                }
            }
        }
    }
void display()
{
    struct node *temp=head;
   if(head == NULL)
      printf("\nList is Empty!!!");
   else
   {
      printf("\nList elements are: \n");
      printf("NULL <--- ");
      while(temp->next!= NULL)
      {
         printf("%d <---> ",temp -> data);
         temp=temp->next;
      }
      printf("%d--->NULL", temp -> data);

   }
}
//    }


